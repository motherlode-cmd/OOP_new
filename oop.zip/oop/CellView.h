//
// Created by motherlode on 08.12.22.
//

#ifndef OOP_CELLVIEW_H
#define OOP_CELLVIEW_H
#include "Cell.h"

class CellView {
public:
    char cellViewer(const Cell &cell, bool isPlayerHere);
};


#endif //OOP_CELLVIEW_H
