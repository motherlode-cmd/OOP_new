#include <iostream>
#include "Mediator.h"
int main() {
    Mediator mediator;
    mediator.start();
    //std::cout << "Hello, World!" << std::endl;
    return 0;
}
